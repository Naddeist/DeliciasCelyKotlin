package com.example.deliciascely;

import android.content.Intent;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.view.View;
import android.view.View.OnClickListener;



public class AdminCategoryActivity extends AppCompatActivity

{

    private ImageView cafe, galleta;
    private ImageView pastel, te;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_category);

        cafe = (ImageView)findViewById(R.id.cafe);
        galleta = (ImageView)findViewById(R.id.galleta);
        pastel = (ImageView)findViewById(R.id.pastel);
        te = (ImageView)findViewById(R.id.te);



        cafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminCategoryActivity.this, AdminAddNewProductActivity.class);
                intent.putExtra("category", "cafe");
                startActivity(intent);
            }
        });

        galleta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminCategoryActivity.this, AdminAddNewProductActivity.class);
                intent.putExtra("category", "galleta");
                startActivity(intent);
            }
        });

        pastel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminCategoryActivity.this, AdminAddNewProductActivity.class);
                intent.putExtra("category", "pastel");
                startActivity(intent);
            }
        });

        te.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AdminCategoryActivity.this, AdminAddNewProductActivity.class);
                intent.putExtra("category", "te");
                startActivity(intent);
            }
        });
    }
}
